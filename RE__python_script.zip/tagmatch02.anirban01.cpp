#include <fstream>
#include <vector>
#include <string>
#include <iostream>
#include <iomanip>
#include <ctime>
#include <sstream>
//#include <valarray>
//#include <cmath>
#include <map>
#include <set>
#include <StringUtils.h>
//#include <tr1/unordered_map>


using namespace std;


int main(int argc, char *argv[]) {

	if (argc != 3) {
		cerr << argc << endl;
		cerr << "Wrong number of parameters." << endl;
		cerr << "Parameters are: " << endl;
		cerr << "tag filename fullpath" << endl;
		cerr << "sam filename fullpath" << endl;
		//cerr << "output filename fullpath" << endl;
		return 1;
	}

	string tagFilename(argv[1]);
	string samFilename(argv[2]);
	//string outputFilename(argv[3]);

	map< string, string > tagmap;

	time_t start = time(0);
	cerr << "start time " << start << endl;

	ifstream tagfile(tagFilename.c_str());
	if (!tagfile) {
		cerr << "Unable to open tag file " << tagFilename << endl;
		return -1;
	}

	ifstream samfile(samFilename.c_str());
	if (!samfile) {
		cerr << "Unable to open sam file " << samFilename << endl;
		return -1;
	}
/*
	ofstream outfile(outputFilename.c_str());
	if (!outfile) {
		cerr << "Unable to open output file " << outputFilename << endl;
		return -1;
	}
*/
	time_t now = time(0);
	cerr << "after open files " << now - start << endl;

	int i;
	int ind;
	int numFound = 0;
	int len = 0;
	int counter = 0;
	stringstream ss;
	vector<string> thisRow;
	string thisChrom = "";
	int thisStart = 0;
	string thisStrand = "";
	string thisId = "";
	string thisTag = "";
	string dummy = "";
	string thisSam = "";
	string thisQname = "";
	string thisFlag = "";
	string thisRname = "";
	int thisPos = 0;
	string thisMapq = "";
	string thisCigar = "";
	string thisMrnm = "";
	string thisMpos = "";
	string thisTlen = "";
	string thisSeq = "";
	string thisQual = "";
	string thisOpt = "";
	string thisLine = "";
	string thisVarietalTag = "";

	while(getline(tagfile, thisLine)) {
		if (counter % 4 == 0) {
			if (thisId == "") {
				;
			} else {
				tagmap.insert(pair< string, string >(thisId, thisTag));
			}
			ss.clear();
			ss.str("");
			ss << thisLine;
			ss >> thisId >> dummy;
			thisId = thisId.substr(1);

			//cerr << "counter % 4 == 0 " << endl << thisId << endl;

		} else {
			if (counter % 4 == 1) {

				//cerr << "counter % 4 == 1" << endl << thisLine << endl;

				ss.clear();
				ss.str("");
				ss << thisLine;
				ss >> thisSeq;
				thisTag = "NA";
				//i = thisSeq.find("ACTTTTTT");

				//cerr << "find pos = " << i << endl;

				//if (i > 18) {
				//	thisTag = thisSeq.substr((i - 17), 10);

					//cerr <<  "tag found " << thisId << " " << thisTag << endl << endl;
				//}

				thisTag = thisSeq.substr(0, 10);
			}
		}
		counter += 1;
	}

	if (thisId == "") {
		;
	} else {
		tagmap.insert(pair< string, string >(thisId, thisTag));
	}

	now = time(0);
	cerr << "after read tag file " << now - start << endl;

	//for (map<string, string>::iterator iter = iter=tagmap.begin(); iter != tagmap.end(); ++iter) {
	//	cerr << iter->first << " " << iter->second << endl;
	//}

	counter = 0;
	string delimiter = "\t";

	while(getline(samfile, thisLine)) {

		if (thisLine.substr(0, 1) == "@") {
			cout << thisLine << endl;
			continue;
		}

		thisRow.clear();
		numFound = StringUtils::SplitString(thisLine, delimiter, thisRow, true);

		//cerr << endl << thisLine << endl;

		//len = thisRow.size() - 1;
		//for (i = 0; i < len; i++) {
		//	cerr << thisRow[i] << "\t";
		//}
		//cerr << thisRow[len] << endl;

		thisQname = thisRow[0];

		//cerr << endl << "thisQname = " << thisQname << endl;

		thisVarietalTag = "NA";

		for (map<string, string>::iterator iter = iter=tagmap.lower_bound(thisQname); iter != tagmap.upper_bound(thisQname); ++iter) {
			thisVarietalTag = iter->second;
			//cerr << "thisVarietalTag = " << thisVarietalTag << endl;
		}
		thisRow.push_back("XV:Z:" + thisVarietalTag);
		len = thisRow.size();
		for (i = 0; i < (len - 1); i++) {
			cout << thisRow[i] << "\t";
		}
		cout << thisRow[len - 1] << endl;
	}

	tagfile.close();
	samfile.close();
	//outfile.close();

	now = time(0);
	cerr << "END " << now - start << endl;

}
