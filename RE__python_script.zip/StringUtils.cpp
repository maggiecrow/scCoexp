#include <vector>
#include <string>
#include <StringUtils.h>

using namespace std;

string StringUtils::trimChar(const string& str, const char charToTrim) {
	string tempStr = str;
	string::size_type pos = tempStr.find_last_not_of(charToTrim);
	if(pos != string::npos) {
		tempStr.erase(pos + 1);
		pos = tempStr.find_first_not_of(charToTrim);
		if(pos != string::npos) tempStr.erase(0, pos);
	}
	else tempStr.erase(tempStr.begin(), tempStr.end());
	return tempStr;
}


void StringUtils::split(const string& s, char c, vector<string>& v) {
   int i = 0;
   int j = s.find(c);

   while (j >= 0) {
      v.push_back(s.substr(i, j-i));
      i = ++j;
      j = s.find(c, j);

      if (j < 0) {
         v.push_back(s.substr(i, s.length( )));
      }
   }
}


int StringUtils::SplitString(const string& input, const string& delimiter, vector<string>& results, bool includeEmpties) {

    int iPos = 0;
    int newPos = -1;
    int sizeS2 = (int)delimiter.size();
    int isize = (int)input.size();

    if((isize == 0) || (sizeS2 == 0)) {
        return 0;
    }

    vector<int> positions;

    newPos = input.find (delimiter, 0);

    if(newPos < 0) {
        return 0;
    }

    int numFound = 0;

    while(newPos >= iPos) {
        numFound++;
        positions.push_back(newPos);
        iPos = newPos;
        newPos = input.find(delimiter, iPos+sizeS2);
    }

    if(numFound == 0) {
        return 0;
    }

    for(int i = 0; i <= (int)positions.size(); ++i ) {

        string s("");
        if(i == 0) {
            s = input.substr(i, positions[i]);
        }
        int offset = positions[i-1] + sizeS2;
        if(offset < isize) {
            if(i == (int)positions.size()) {
                s = input.substr(offset);
            } else if(i > 0) {
                s = input.substr(positions[i-1] + sizeS2, positions[i] - positions[i-1] - sizeS2);
            }
        }
        if( includeEmpties || (s.size() > 0 )) {
            results.push_back(s);
        }
    }
    return numFound;
}
