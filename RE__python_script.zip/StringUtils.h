#ifndef __STRINGUTILS_H_
#define __STRINGUTILS_H_

#include <vector>
#include <string>

using namespace std;

class StringUtils {

public:

	static string trimChar(const string& str,
		const char charToTrim);

	static void split(const string& s,
		char c,
		vector<string>& v);

	static int SplitString(const string& input,
		const string& delimiter,
		vector<string>& results,
		bool includeEmpties = true);

};

#endif
