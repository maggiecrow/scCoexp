g++ -I"/mnt/wigclust5/data/safe/kendall/cpppgms" -c -Wall -O StringUtils.cpp
g++ -I"/mnt/wigclust5/data/safe/kendall/cpppgms" -o tagmatch02.anirban01.exe StringUtils.o tagmatch02.anirban01.cpp
